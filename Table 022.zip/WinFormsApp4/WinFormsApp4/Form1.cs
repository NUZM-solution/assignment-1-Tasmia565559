 using System;
    using System.Windows.Forms;

    namespace LoginApp
    {
        public partial class Form1 : Form
        {
            public Form1()
            {
                InitializeComponent();
            }

            private void btnLogin_Click(object sender, EventArgs e)
            {
                // Define correct username and password
                string user = "tasmia";
                string pass = "22011556-022";

                // Check if entered username and password are correct
                if (txtUser.Text == user && txtPass.Text == pass)
                {
                    MessageBox.Show("Welcome User!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Invalid username or password", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtUser.Clear();
                    txtPass.Clear();
                    txtUser.Focus();
                }
            }

            private void btnReset_Click(object sender, EventArgs e)
            {
                // Clear the text fields
                txtUser.Clear();
                txtPass.Clear();
                txtUser.Focus();
            }

            private void btnExit_Click(object sender, EventArgs e)
            {
                // Close the application
                this.Close();
            }
        }
    }


﻿partial class Form1
{
    private System.Windows.Forms.TextBox txt_studentName;
    private System.Windows.Forms.TextBox txt_courseCode;
    private System.Windows.Forms.TextBox txt_courseTitle;
    private System.Windows.Forms.TextBox txt_obtainedMarks;
    private System.Windows.Forms.TextBox txt_totalMarks;
    private System.Windows.Forms.TextBox txt_grade;
    private System.Windows.Forms.TextBox txt_status;
    private System.Windows.Forms.Button btn_add;
    private System.Windows.Forms.DataGridView dataGridView1;

    private System.Windows.Forms.Label lbl_studentName;
    private System.Windows.Forms.Label lbl_courseCode;
    private System.Windows.Forms.Label lbl_courseTitle;
    private System.Windows.Forms.Label lbl_obtainedMarks;
    private System.Windows.Forms.Label lbl_totalMarks;
    private System.Windows.Forms.Label lbl_grade;
    private System.Windows.Forms.Label lbl_status;

    private void InitializeComponent()
    {
        this.txt_studentName = new System.Windows.Forms.TextBox();
        this.txt_courseCode = new System.Windows.Forms.TextBox();
        this.txt_courseTitle = new System.Windows.Forms.TextBox();
        this.txt_obtainedMarks = new System.Windows.Forms.TextBox();
        this.txt_totalMarks = new System.Windows.Forms.TextBox();
        this.txt_grade = new System.Windows.Forms.TextBox();
        this.txt_status = new System.Windows.Forms.TextBox();
        this.btn_add = new System.Windows.Forms.Button();
        this.dataGridView1 = new System.Windows.Forms.DataGridView();

        this.lbl_studentName = new System.Windows.Forms.Label();
        this.lbl_courseCode = new System.Windows.Forms.Label();
        this.lbl_courseTitle = new System.Windows.Forms.Label();
        this.lbl_obtainedMarks = new System.Windows.Forms.Label();
        this.lbl_totalMarks = new System.Windows.Forms.Label();
        this.lbl_grade = new System.Windows.Forms.Label();
        this.lbl_status = new System.Windows.Forms.Label();

        ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
        this.SuspendLayout();

        // Setup TextBoxes and Labels
        // Student Name
        this.lbl_studentName.Text = "Student Name";
        this.lbl_studentName.Location = new System.Drawing.Point(20, 20);
        this.txt_studentName.Location = new System.Drawing.Point(150, 20);

        // Course Code
        this.lbl_courseCode.Text = "Course Code";
        this.lbl_courseCode.Location = new System.Drawing.Point(20, 50);
        this.txt_courseCode.Location = new System.Drawing.Point(150, 50);

        // Course Title
        this.lbl_courseTitle.Text = "Course Title";
        this.lbl_courseTitle.Location = new System.Drawing.Point(20, 80);
        this.txt_courseTitle.Location = new System.Drawing.Point(150, 80);

        // Obtained Marks
        this.lbl_obtainedMarks.Text = "Obtained Marks";
        this.lbl_obtainedMarks.Location = new System.Drawing.Point(20, 110);
        this.txt_obtainedMarks.Location = new System.Drawing.Point(150, 110);

        // Total Marks
        this.lbl_totalMarks.Text = "Total Marks";
        this.lbl_totalMarks.Location = new System.Drawing.Point(20, 140);
        this.txt_totalMarks.Location = new System.Drawing.Point(150, 140);

        // Grade
        this.lbl_grade.Text = "Grade";
        this.lbl_grade.Location = new System.Drawing.Point(20, 170);
        this.txt_grade.Location = new System.Drawing.Point(150, 170);

        // Status
        this.lbl_status.Text = "Status";
        this.lbl_status.Location = new System.Drawing.Point(20, 200);
        this.txt_status.Location = new System.Drawing.Point(150, 200);

        // Add Button
        this.btn_add.Text = "Add Record";
        this.btn_add.Location = new System.Drawing.Point(150, 230);
        this.btn_add.Click += new System.EventHandler(this.btn_add_Click);

        // DataGridView
        this.dataGridView1.Location = new System.Drawing.Point(20, 270);
        this.dataGridView1.Size = new System.Drawing.Size(500, 200);
        this.dataGridView1.AllowUserToAddRows = false;

        // Form settings
        this.ClientSize = new System.Drawing.Size(600, 500);
        this.Controls.Add(this.lbl_studentName);
        this.Controls.Add(this.txt_studentName);
        this.Controls.Add(this.lbl_courseCode);
        this.Controls.Add(this.txt_courseCode);
        this.Controls.Add(this.lbl_courseTitle);
        this.Controls.Add(this.txt_courseTitle);
        this.Controls.Add(this.lbl_obtainedMarks);
        this.Controls.Add(this.txt_obtainedMarks);
        this.Controls.Add(this.lbl_totalMarks);
        this.Controls.Add(this.txt_totalMarks);
        this.Controls.Add(this.lbl_grade);
        this.Controls.Add(this.txt_grade);
        this.Controls.Add(this.lbl_status);
        this.Controls.Add(this.txt_status);
        this.Controls.Add(this.btn_add);
        this.Controls.Add(this.dataGridView1);

        ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
        this.ResumeLayout(false);
        this.PerformLayout();
    }
}

using System;
using System.Windows.Forms;

namespace StudentCourseInfo
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles(); // Enable visual styles for the application
            Application.SetCompatibleTextRenderingDefault(false); // Set default text rendering
            Application.Run(new Form1()); // Run the main form
        }
    }
}

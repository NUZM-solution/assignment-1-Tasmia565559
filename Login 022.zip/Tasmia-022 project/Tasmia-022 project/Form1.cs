using System;
using System.Data;
using System.Windows.Forms;

public partial class Form1 : Form
{
    DataTable dt = new DataTable();

    public Form1()
    {
        InitializeComponent(); // Initialize all components (UI)
        CreateNewRow();        // Initialize columns on form load
    }

    public void CreateNewRow()
    {
        if (dt.Columns.Count == 0) // Create columns only once
        {
            dt.Columns.Add(new DataColumn("Student Name", typeof(string)));
            dt.Columns.Add(new DataColumn("Course Code", typeof(string)));
            dt.Columns.Add(new DataColumn("Course Title", typeof(string)));
            dt.Columns.Add(new DataColumn("Obtained Marks", typeof(int)));
            dt.Columns.Add(new DataColumn("Total Marks", typeof(int)));
            dt.Columns.Add(new DataColumn("Grade", typeof(string)));
            dt.Columns.Add(new DataColumn("Status", typeof(string)));
        }

        dataGridView1.DataSource = dt; // Bind DataTable to DataGridView
    }

    public void AddRowToDataTable()
    {
        // Validate input data before adding
        if (int.TryParse(txt_obtainedMarks.Text, out int obtainedMarks) &&
            int.TryParse(txt_totalMarks.Text, out int totalMarks))
        {
            // Add a new row with user inputs
            dt.Rows.Add(
                txt_studentName.Text,
                txt_courseCode.Text,
                txt_courseTitle.Text,
                obtainedMarks,
                totalMarks,
                txt_grade.Text,
                txt_status.Text
            );

            // Clear inputs after adding
            ClearInputs();
        }
        else
        {
            MessageBox.Show("Please enter valid marks.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void btn_add_Click(object sender, EventArgs e)
    {
        AddRowToDataTable(); // Call method to add a new row when the button is clicked
    }

    private void ClearInputs()
    {
        // Clear all input fields
        txt_studentName.Clear();
        txt_courseCode.Clear();
        txt_courseTitle.Clear();
        txt_obtainedMarks.Clear();
        txt_totalMarks.Clear();
        txt_grade.Clear();
        txt_status.Clear();
    }
}
